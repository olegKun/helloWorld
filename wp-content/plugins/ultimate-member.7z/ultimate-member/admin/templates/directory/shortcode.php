<div class="um-admin-metabox">

	<p><?php echo $ultimatemember->shortcodes->get_shortcode( get_the_ID() ); ?></p>
	
</div>